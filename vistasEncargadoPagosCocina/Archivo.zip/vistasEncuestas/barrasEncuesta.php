
        <div>
                 <canvas id="graficaVotos" width="400" height="300"></canvas>
        </div>

